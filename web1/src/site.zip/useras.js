import React, { useEffect, useState } from "react";
import { ProgressBar, Navbar, Nav, Container } from "react-bootstrap";
import styled from "styled-components";
import { useParams, Link } from "react-router-dom";
import axios from "axios";

let Outcontainer = styled.div`
  height: 100%;
  width: 100%;
  background-color: floralwhite;
`;
let Header = styled.div`
  height: 10%;
  width: 100%;
`;
let Span2 = styled.div`
  display: flex;
  justify-content: space-around;
`;
let Span1 = styled.div``;
let stage = 1;

function Useras(props) {
  let { id } = useParams();
  let email = id;
  let [progress, progress변경] = useState(0);

  useEffect(() => {
    axios.post("http://localhost:8080/level" + String(stage)).then((res) => {
      if (progress < 100) {
        progress변경(progress + 34);
        progress += 34;
        stage += 1;
      }
    });
  }, [progress]);
  let url = "/download/" + email;

  return (
    <Outcontainer>
      <Header>
        <Navbar bg="light" variant="light">
          <Container>
            <Nav className="me-auto">
              <Nav.Link href="/">Home</Nav.Link>
              <Nav.Link href="/form1">Font-Generation</Nav.Link>
              <Nav.Link href="/form2">Font-AS</Nav.Link>
              <Nav.Link href="/request">Q&A</Nav.Link>
              <Nav.Link href="/check">UserCheck</Nav.Link>
            </Nav>
          </Container>
        </Navbar>
      </Header>
      <h1>{id}님의 font 생성중 ...</h1>

      <div>
        <ProgressBar now={progress} />
      </div>
      <Span2>
        <Span1>png -&gt; ttf</Span1>
        <Span1>font model running...</Span1>
        <Span1>png -&gt; ttf</Span1>
      </Span2>
      {progress >= 100 ? (
        <div>
          <h2>your download link</h2>
          <Link to={url}>DownLoad Page</Link>
        </div>
      ) : null}
    </Outcontainer>
  );
}

export default Useras;