import React, { useEffect, useState } from "react";
import { ProgressBar, Navbar, Nav, Container, Toast } from "react-bootstrap";
import styled from "styled-components";
import { useParams, Link } from "react-router-dom";
import axios from "axios";

let Outcontainer = styled.div`
  height: 100%;
  width: 100%;
  background-color: floralwhite;
`;
let Header = styled.div`
  height: 10%;
  width: 100%;
`;
let Span2 = styled.div`
  display: flex;
  justify-content: space-around;
`;
let Span1 = styled.div``;
let stage = 1;
let buttonshow = 0;
function User(props) {
  let { id } = useParams();
  let email = id;
  let [progress, progress변경] = useState(0);
  let [progress1, progress1변경] = useState(0);
  let [fontname, fontname변경] = useState("");

  let ttfcontinue = () => {
    buttonshow = 0;
    axios.post("http://localhost:8080/level3").then((res) => {
      progress1변경(100);
    });
  };
  let toas = () => {
    buttonshow = 0;
    window.location.replace("/form2");
  };
  useEffect(() => {
    axios.post("http://localhost:8080/level" + String(stage)).then((res) => {
      if (stage === 2) {
        fontname변경(res.data.fontName);
      }
      progress1변경(progress1 + 34);
      if (progress < 33) {
        progress변경(progress + 34);
        buttonshow = 1;
        stage += 1;
      }
    });
  }, [progress]);
  let url = "/download/" + email;

  return (
    <Outcontainer>
      <Header>
        <Navbar bg="light" variant="light">
          <Container>
            <Nav className="me-auto">
              <Nav.Link href="/">Home</Nav.Link>
              <Nav.Link href="/form1">Font-Generation</Nav.Link>
              <Nav.Link href="/form2">Font-AS</Nav.Link>
              <Nav.Link href="/request">Q&A</Nav.Link>
              <Nav.Link href="/check">UserCheck</Nav.Link>
            </Nav>
          </Container>
        </Navbar>
      </Header>
      <h1>{id}님의 font 생성중 ...</h1>

      <div>
        <ProgressBar now={progress1} />
      </div>
      <Span2>
        <Span1>png -&gt; ttf</Span1>
        <Span1>font model running...</Span1>
        <Span1>png -&gt; ttf</Span1>
      </Span2>
      {progress1 >= 67 ? (
        <div>
          <h3>png</h3>
          <img src={`/${fontname}1.png`} />
          <img src={`/${fontname}2.png`} />
          <img src={`/${fontname}3.png`} />
          <img src={`/${fontname}4.png`} />
          <img src={`/${fontname}5.png`} />
          <img src={`/${fontname}6.png`} />
          <img src={`/${fontname}7.png`} />
          <img src={`/${fontname}8.png`} />
          <img src={`/${fontname}9.png`} />
          <img src={`/${fontname}10.png`} />
          <img src={`/${fontname}11.png`} />
        </div>
      ) : null}
      {buttonshow === 1 ? (
        <div>
          <h3>Font AS를 받으시겠습니까?</h3>
          <button onClick={toas}>YES</button>
          <button onClick={ttfcontinue}>NO</button>
        </div>
      ) : null}
      {progress1 >= 100 ? (
        <div>
          <h2>your download link</h2>
          <Link to={url}>DownLoad Page</Link>
        </div>
      ) : null}
    </Outcontainer>
  );
}

export default User;