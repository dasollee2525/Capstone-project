import React, { useState } from "react";
import { Nav, Navbar, Container } from "react-bootstrap";
import { Link, useParams } from "react-router-dom";
import axios from "axios";
import styled from "styled-components";
let Outcontainer = styled.div`
  height: 100%;
  width: 100%;
  background-color: floralwhite;
`;
function Down() {
  let { id } = useParams();
  let [user_ttf, user_ttf변경] = useState("");
  axios
    .post(
      "http://localhost:8080/download",
      { id },
      {
        headers: {
          "Content-type": "application/json",
          Accept: "application/json",
        },
      }
    )
    .then((result) => {
      user_ttf변경("/" + result.data.fontName + ".ttf");
    });
  return (
    <Outcontainer>
      <Navbar bg="light" variant="light">
        <Container>
          <Navbar.Brand href="/">Home</Navbar.Brand>
          <Nav className="me-auto">
            <Nav.Link href="/form1">Font-Generation</Nav.Link>
            <Nav.Link href="/form2">Font-AS</Nav.Link>
            <Nav.Link href="/request">Q&A</Nav.Link>
          </Nav>
        </Container>
      </Navbar>
      <h1>{id}님의 Font</h1>
      <h2>
        <Link to={user_ttf} target="_blank" download>
          {id}님만의 font
        </Link>
      </h2>
    </Outcontainer>
  );
}
export default Down;