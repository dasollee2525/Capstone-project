import React from "react";
import {
  InputGroup,
  FormControl,
  Nav,
  Navbar,
  Container,
  Form,
  Button,
} from "react-bootstrap";
import styled from "styled-components";
import { useState } from "react";
import axios from "axios";
import MakeButton from "../components/button";
import {
  initial1,
  initial_code,
  medial1,
  medial_code,
  final1,
  final_code,
} from "./word";
let style = {
  a: {
    width: "20%",
  },
  b: {
    width: "200px",
    cursor: "pointer",
    margin: "20px",
  },
  x: {
    width: "8%",
  },
};
let Outcontainer = styled.div`
  height: 100%;
  width: 100%;
  background-color: floralwhite;
`;

let Header = styled.div`
  height: 10%;
  width: 100%;
`;
let Intro = styled.div`
  heigth: 10%;
  width: 100%;
  display: flex;
  align-items: center;
`;
let Information = styled.div`
  height: 30%;
  width: 60%;
`;
let Uploadpdf = styled.div`
  display: flex;
  align-items: center;
`;
let Upload = styled.div`
  height: 20%;
  display: inline;
`;
let Spantext = styled.span`
  font-size: ${(props) => props.fontsize};
  display: inline-block;
  margin: ${(props) => props.marginsize};
`;
let Textdiv = styled.div`
  padding: ${(props) => props.paddingsize};
  height: 90%;
`;
let Conbutton = styled.button`
  background-color: white;
  width: 50px;
  margin: 5px;
  text-align: center;
  cursor: pointer;
  border-radius: 10px;
`;
let Submit = styled.div`
  padding: ${(props) => props.paddingsize};
  margin-right: 50px;
`;
let Consonant = styled.div`
  display: flex;
  width: 100%;
  margin: ${(props) => props.marginsize};
`;
let Count = styled.div`
  width: 100%;
  height: 10%;
`;
let Fileform = styled.div`
  display: flex;
  align-items: center;
  width: 100%;
`;
let Radio = styled.input`
  margin: ${(props) => props.marginsize};
`;
let Part2 = styled.div``;
function Form2() {
  let initial = Object.keys(initial1);
  let medial = Object.keys(medial1);
  let final = Object.keys(final1);
  let consonant_length = 10;
  let [pdf, pdf변경] = useState(0);
  let [initial_start, initial_start변경] = useState(0);
  let [medial_start, medial_start변경] = useState(0);
  let [final_start, final_start변경] = useState(0);
  let [as_part, as_part변경] = useState([[], [], []]);
  let [fontname, fontname변경] = useState("");
  let [email, email변경] = useState("");
  let [check, check변경] = useState("0");
  let [img1, img1변경] = useState(null);
  let [img2, img2변경] = useState(null);
  let [img3, img3변경] = useState(null);
  let [font_as, font_as변경] = useState([[], [], []]);
  let [font_as_code, font_as_code변경] = useState([[], [], []]);
  let result = [[], [], []];
  let result_code = [[], [], []];
  let [font_part, font_part변경] = useState(["", "", ""]);
  const handleclick = (e) => {
    const fd = new FormData();
    if (check === "1") {
      fd.append("file", img1);
    } else if (check === "2") {
      fd.append("file", img1);
      fd.append("file", img2);
    } else if (check === "3") {
      fd.append("file", img1);
      fd.append("file", img2);
      fd.append("file", img3);
    }
    axios.post(
      "http://localhost:8080/as1",
      {
        fileName: email,
        fontName: fontname,
        email,
        check,
        font_part,
        as: "1",
        as_part,
        font_as,
        font_as_code,
      },
      {
        headers: {
          "Content-type": "application/json",
          Accept: "application/json",
        },
      }
    );
    axios
      .post("http://localhost:8080/as2", fd, {})
      .then(window.location.replace("/useras/" + email));
  };
  const pdfclick = () => {
    pdf변경(1);
    let font_as_c = [[], [], []];
    font_as_c[0] = result[0];
    font_as_c[1] = result[1];
    font_as_c[2] = result[2];
    font_as변경(font_as_c);
    let font_as_code_c = [[], [], []];
    font_as_code_c[0] = result_code[0];
    font_as_code_c[1] = result_code[1];
    font_as_code_c[2] = result_code[2];
    font_as_code변경(font_as_code_c);
  };
  let user_initial = () => {
    for (let i = 0; i < as_part[0].length; i++) {
      result[0].push(initial1[as_part[0][i]]);
      result_code[0].push(initial_code[as_part[0][i]]);
    }
    return result[0];
  };
  let user_medial = () => {
    for (let i = 0; i < as_part[1].length; i++) {
      result[1].push(medial1[as_part[1][i]]);
      result_code[1].push(medial_code[as_part[1][i]]);
    }

    return result[1];
  };
  let user_final = () => {
    for (let i = 0; i < as_part[2].length; i++) {
      result[2].push(final1[as_part[2][i]]);
      result_code[2].push(final_code[as_part[2][i]]);
    }
    return result[2];
  };
  let initial_rendering = () => {
    let result = [];
    for (let i = initial_start; i < initial_start + consonant_length; i++) {
      result.push(
        <Conbutton
          key={i}
          onClick={(e) => {
            let as_part_c = [...as_part];
            let a = true;

            for (let j = 0; j < as_part_c[0].length; j++) {
              if (as_part_c[0][j] == initial[i]) {
                as_part_c[0].splice(j);
                a = false;
                break;
              }
            }
            if (a) {
              as_part_c[0].push(initial[i]);
            }
            as_part변경(as_part_c);
          }}
        >
          {initial[i]}
        </Conbutton>
      );
    }
    return result;
  };
  let middle_rendering = () => {
    let result = [];
    for (let i = medial_start; i < medial_start + consonant_length; i++) {
      result.push(
        <Conbutton
          key={i}
          onClick={() => {
            let as_part_c = [...as_part];
            let a = true;
            for (let j = 0; j < as_part_c[1].length; i++) {
              if (as_part_c[1][j] === medial[i]) {
                as_part_c[1].splice(j);
                a = false;
                break;
              }
            }
            if (a) {
              as_part_c[1].push(medial[i]);
            }
            as_part변경(as_part_c);
          }}
        >
          {medial[i]}
        </Conbutton>
      );
    }
    return result;
  };
  let final_rendering = () => {
    let result = [];
    for (let i = final_start; i < final_start + consonant_length; i++) {
      result.push(
        <Conbutton
          key={i}
          onClick={() => {
            let as_part_c = [...as_part];
            let a = true;
            for (let j = 0; j < as_part_c[2].length; i++) {
              if (as_part_c[2][j] === final[i]) {
                as_part_c[2].splice(j);
                a = false;
                break;
              }
            }
            if (a) {
              as_part_c[2].push(final[i]);
            }
            as_part변경(as_part_c);
          }}
        >
          {final[i]}
        </Conbutton>
      );
    }
    return result;
  };
  const initial_leftmove = () => {
    if (initial_start > 0) {
      initial_start변경(initial_start - 1);
    }
  };

  const initial_rightmove = () => {
    if (initial_start < initial.length - consonant_length) {
      initial_start변경(initial_start + 1);
    }
  };

  const medial_leftmove = () => {
    if (medial_start > 0) {
      medial_start변경(medial_start - 1);
    }
  };

  const medial_rightmove = () => {
    if (medial_start < medial.length - consonant_length) {
      medial_start변경(medial_start + 1);
    }
  };
  const final_leftmove = () => {
    if (final_start > 0) {
      final_start변경(final_start - 1);
    }
  };

  const final_rightmove = () => {
    if (final_start < final.length - consonant_length) {
      final_start변경(final_start + 1);
    }
  };
  return (
    <Outcontainer>
      <Header>
        <Navbar bg="light" variant="light">
          <Container>
            <Nav className="me-auto">
              <Nav.Link href="/">Home</Nav.Link>
              <Nav.Link href="/form1">Font-Generation</Nav.Link>
              <Navbar.Brand href="/form2">Font-AS</Navbar.Brand>
              <Nav.Link href="/request">Q&A</Nav.Link>
              <Nav.Link href="/check">UserCheck</Nav.Link>
            </Nav>
          </Container>
        </Navbar>
      </Header>
      <Textdiv paddingsize={"0 0 0 200px"}>
        <Intro>
          <Spantext fontsize={"40px"} marginsize={"0 0 30px 300px"}>
            <b>A/S Service</b>
          </Spantext>
        </Intro>
        <Uploadpdf>
          <Upload>
            <Spantext size={"20px"}>
              Select the consonants that you want to revise
            </Spantext>
            <Consonant marginsize={"0 0 30px 0"}>
              <InputGroup.Text id="inputGroup-sizing-lg" style={style.x}>
                initial
              </InputGroup.Text>
              <Conbutton onClick={initial_leftmove}>&#171;</Conbutton>
              {initial_rendering()}
              <Conbutton onClick={initial_rightmove}>&#187;</Conbutton>
              <h3>{as_part[0]}</h3>
            </Consonant>
            <Consonant marginsize={"0 0 30px 0"}>
              <InputGroup.Text id="inputGroup-sizing-lg" style={style.x}>
                medial
              </InputGroup.Text>
              <Conbutton onClick={medial_leftmove}>&#171;</Conbutton>
              {middle_rendering()}
              <Conbutton onClick={medial_rightmove}>&#187;</Conbutton>
              <h3>{as_part[1]}</h3>
            </Consonant>
            <Consonant marginsize={"0 0 30px 0"}>
              <InputGroup.Text id="inputGroup-sizing-lg" style={style.x}>
                final
              </InputGroup.Text>
              <Conbutton onClick={final_leftmove}>&#171;</Conbutton>
              {final_rendering()}
              <Conbutton onClick={final_rightmove}>&#187;</Conbutton>
              <h3>{as_part[2]}</h3>
            </Consonant>
          </Upload>
          <Submit paddingsize={"0 0 0 200px"}>
            <MakeButton
              text={"getpdf"}
              backgroundcolor={"lightyellow"}
              color={"black"}
              paddingsize={"2px"}
              fontsize={"20px"}
              marginsize={"10px"}
              radius={"10px"}
              width={"200px"}
              onClick={pdfclick}
            ></MakeButton>
          </Submit>
          {pdf === 1 ? (
            <div>
              <div>아래 글자를 써서 제출하세요</div>
              {user_initial()}
              <br />
              {user_medial()}
              <br />
              {user_final()}
            </div>
          ) : null}
        </Uploadpdf>

        <div>
          {" "}
          <Part2>
            <Information>
              <InputGroup size="lg">
                <InputGroup.Text id="inputGroup-sizing-lg" style={style.a}>
                  FONT NAME
                </InputGroup.Text>
                <FormControl
                  aria-label="Large"
                  aria-describedby="inputGroup-sizing-sm"
                  placeholder="font name"
                  onChange={(e) => {
                    fontname변경(e.target.value);
                  }}
                />
              </InputGroup>
              <br></br>
              <InputGroup size="lg">
                <InputGroup.Text id="inputGroup-sizing-lg" style={style.a}>
                  E-mail
                </InputGroup.Text>
                <FormControl
                  aria-label="Large"
                  aria-describedby="inputGroup-sizing-sm"
                  placeholder="E-mail Address"
                  onChange={(e) => {
                    email변경(e.target.value);
                  }}
                />
              </InputGroup>
            </Information>
            <Count>
              <Spantext fontsize={"20px"}>
                The number of handwriting (maximum 3)
              </Spantext>
              <div>
                <label>
                  <Radio
                    type="checkbox"
                    name="number"
                    marginsize={"20px"}
                    onClick={() => {
                      check변경("1");
                    }}
                  />
                  1
                </label>
                &nbsp;&nbsp;
                <label>
                  <Radio
                    type="checkbox"
                    name="number"
                    marginsize={"20px"}
                    onClick={() => {
                      check변경("2");
                    }}
                  />{" "}
                  2
                </label>
                &nbsp;&nbsp;
                <label>
                  <Radio
                    type="checkbox"
                    name="number"
                    marginsize={"20px"}
                    onClick={() => {
                      check변경("3");
                    }}
                  />{" "}
                  3
                </label>
              </div>
            </Count>
            <Upload>
              <div>
                <Spantext fontsize={"20px"} margin={"0 100px 0 0"}>
                  Upload File and Choose the gan of consonant respectively
                </Spantext>
                <Spantext fontsize={"20px"}>* jpg 파일로 제출해주세요</Spantext>
              </div>
              <div>
                <Fileform>
                  <Form.Group controlId="formFileLg" className="mb-3">
                    <Form.Control
                      type="file"
                      size="lg"
                      onChange={(e) => {
                        console.log(e.target.files[0]);
                        img1변경(e.target.files[0]);
                      }}
                    />
                  </Form.Group>
                  <div>
                    <label>
                      <Radio
                        type="checkbox"
                        name="number"
                        marginsize={"20px"}
                        onClick={() => {
                          let temp = [...font_part];
                          temp[0] = 0;
                          font_part변경(temp);
                        }}
                      />
                      initial
                    </label>
                    &nbsp;&nbsp;
                    <label>
                      <Radio
                        type="checkbox"
                        name="number"
                        marginsize={"20px"}
                        onClick={() => {
                          let temp = [...font_part];
                          temp[1] = 0;
                          font_part변경(temp);
                        }}
                      />{" "}
                      medial
                    </label>
                    &nbsp;&nbsp;
                    <label>
                      <Radio
                        type="checkbox"
                        name="number"
                        marginsize={"20px"}
                        onClick={() => {
                          let temp = [...font_part];
                          temp[2] = 0;
                          font_part변경(temp);
                        }}
                      />{" "}
                      final
                    </label>
                  </div>
                </Fileform>
                <Fileform>
                  <Form.Group controlId="formFileLg" className="mb-3">
                    <Form.Control
                      type="file"
                      size="lg"
                      onChange={(e) => {
                        console.log(e.target.files[0]);
                        img2변경(e.target.files[0]);
                      }}
                    />
                  </Form.Group>
                  <div>
                    <label>
                      <Radio
                        type="checkbox"
                        name="number"
                        marginsize={"20px"}
                        onClick={() => {
                          let temp = [...font_part];
                          temp[0] = 1;
                          font_part변경(temp);
                        }}
                      />
                      initial
                    </label>
                    &nbsp;&nbsp;
                    <label>
                      <Radio
                        type="checkbox"
                        name="number"
                        marginsize={"20px"}
                        onClick={() => {
                          let temp = [...font_part];
                          temp[1] = 1;
                          font_part변경(temp);
                        }}
                      />{" "}
                      medial
                    </label>
                    &nbsp;&nbsp;
                    <label>
                      <Radio
                        type="checkbox"
                        name="number"
                        marginsize={"20px"}
                        onClick={() => {
                          let temp = [...font_part];
                          temp[0] = 2;
                          font_part변경(temp);
                        }}
                      />{" "}
                      final
                    </label>
                  </div>
                </Fileform>
                <Fileform>
                  <Form.Group controlId="formFileLg" className="mb-3">
                    <Form.Control
                      type="file"
                      size="lg"
                      onChange={(e) => {
                        console.log(e.target.files[0]);
                        img3변경(e.target.files[0]);
                      }}
                    />
                  </Form.Group>
                  <div>
                    <label>
                      <Radio
                        type="checkbox"
                        name="number"
                        marginsize={"20px"}
                        onClick={() => {
                          let temp = [...font_part];
                          temp[0] = 2;
                          font_part변경(temp);
                        }}
                      />
                      initial
                    </label>
                    &nbsp;&nbsp;
                    <label>
                      <Radio
                        type="checkbox"
                        name="number"
                        marginsize={"20px"}
                        onClick={() => {
                          let temp = [...font_part];
                          temp[1] = 2;
                          font_part변경(temp);
                        }}
                      />{" "}
                      medial
                    </label>
                    &nbsp;&nbsp;
                    <label>
                      <Radio
                        type="checkbox"
                        name="number"
                        marginsize={"20px"}
                        onClick={() => {
                          let temp = [...font_part];
                          temp[2] = 2;
                          font_part변경(temp);
                        }}
                      />{" "}
                      final
                    </label>
                  </div>
                </Fileform>
                <Submit paddingsize={"0 0 0 300px"}>
                  <Button
                    as="input"
                    type="submit"
                    value="Submit"
                    onClick={handleclick}
                    style={style.b}
                  />
                </Submit>
              </div>
            </Upload>
          </Part2>
        </div>
      </Textdiv>
    </Outcontainer>
  );
}
export default Form2;